declare module "node-quickbooks";
declare module "intuit-oauth"

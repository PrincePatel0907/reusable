import creditNotes from '../qbController/creditNotes';
import refundReceipt from '../qbController/refundReceipt';
import callback from '../qbController/callback';

export default {
    creditNotes,
    refundReceipt,
    callback
};

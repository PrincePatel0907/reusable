const QBOConfig = {
    QUICKBOOK_CLIENTID: "ABBX2cBSunTPSJ0jzImlRzHRx3zTU5FZoaA87fPOg5koXD3eQk",
    QUICKBOOK_CLIENTSECRET: "s2Ha92dwp8daY1oUMgDdstBWwFFSmoXHxMwqE60g",
    QUICKBOOK_REDIRECT_URI: "http://localhost:3000/callback",
    QUICKBOOK_ENVIRONMENT: "Sandbox"
  };
  
  
  export { QBOConfig };